def question1(first_string,second_string):
  """ Given Two strings, determine whether anagram of t is a substring of
  s
  """

  if first_string is None or second_string is None:
      return None
  if len(first_string) == 0 or len(second_string) == 0:
      return None
  total_num = len(second_string)
  num = 0
  # Check each letter specifically in string t.
  for letter in list(second_string):
    # Check each letter in string s.
    for sec_letter in list(first_string):
      if letter == sec_letter:
        num+=1
        # Jump out of the nested for loop if the goal is reached.
        break
  if total_num == num:
    return True
  else:
    return False

print "This is question 1 test case:"
print question1("alexleu","al")
# Output is True.
print question1("","df")
# Output is None..
print question1(None,None)
# Output is None.


def question2(string):
  """ Given a string a, find the longest palindromic
  substring contained in an a

  Args:
    string: String that is orignally inserted.
  """

  if string == "":
      return None

  # If the lenght is less than or equal to two, the palindrome is the string
  # itself.
  length = len(string)
  if length <= 2:
    if (string[0] != string[length-1]):
      return ''
    else:
      return string
  result = ""

  # Loop to check each combinations of strings.
  # Check the first index all the way to the end.
  for i in range(0,length):
    palindrome = SearchForPalindrome(string, i, i)
    if len(palindrome) > len(result): result = palindrome
    palindrome = SearchForPalindrome(string, i, i+1)
    if len(palindrome) > len(result): result = palindrome
  print result

def SearchForPalindrome(string, start, end):
  while (start>=0 and end < len(string) and string[start] == string[end]):
    start -=1
    end +=1
  return string[start+1:end]

print "This is question 2 test case:"
print question2("HITHERE")
# Output is ERE.
print question2("")
# Output is None.
print question2("LKJFOEWJOFJOWIFJOWJEJFKDLSJLF:JSFJSFLKJSLCJIOWEJFOIJFPE")
# Output is JEJ.

ADJACENT_LIST_STRUCTURED = {'A':[('B',2),('C',8)],'B':[('A',2),('C',5)],'C':[('B',5), ('A', 8)]}
def question3(graph):
  """ Providing a graph, show the minimum spanning tree of the total weight
  """
  if not graph:
      return None
  if type(graph) is not dict:
      return "Input is not a dictionary."
  # Start off for the for the first indexes. Look for the shortest path of way.
  shortest_path = {}
  checked_vertex = []
  for vertex in graph:
    weight = None
    for adj in graph[vertex]:
      if (weight is None or adj[1] < weight) and adj[0] not in checked_vertex:
        weight = adj[1]
        shortest_path[vertex] = [adj]
        checked_vertex.append(adj[0])
  return shortest_path

print "This is question 3 test cases:"
print question3(ADJACENT_LIST_STRUCTURED)
print question3({})
print question3([1,2,3])

TREE_LIST = [[0,1,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[1,0,0,0,1],[0,0,0,0,0]]
ROOT_INT = 3
CHILD_1 = 1
CHILD_2 = 4

def TreeLevelOutput(tree,root_integer,child,level):
    """ Return dictionary for each level of the tree is in, and the value on top.
    
    Args:
      tree: tree: represented as matrix
      root_integer: Non negative integer
      level: The level the tree is currently in.
    """
    if root_integer == child:
        return 0, None
    i = 0
    for node in tree:
        if node[child] == 1 and i == root_integer:
            return level, i
        elif node[child]==1:
            level +=1
            return TreeLevelOutput(tree,i,child,level)
        else:
            pass
        i +=1

def question4(tree, root_integer, child_1, child_2):
  """ Find the least common ancestor between two nodes on a binary search tree,
  and find the farthest node that is common for both.
  Args:
    tree: tree represented as matrix
    root_integer: Non negative integer represents the root.
    child_1: First Node in the particular order.
    child_2: Second node that is checked by the tools.
  """
  
  if type(tree) is not list:
      return None
  child_1_level = TreeLevelOutput(tree,root_integer,child_1,1)
  child_2_level = TreeLevelOutput(tree,root_integer,child_2,1)
  # After finding out the level ground on each node, determine the common
  if child_1_level[0] <= child_2_level[0]:
      return child_1_level[1]
  else:
      return child_2_level[1]

print "This is question 4 test cases:"
print question4(TREE_LIST,ROOT_INT,CHILD_1,CHILD_2)
print question4(TREE_LIST,ROOT_INT,CHILD_1,CHILD_1)
print question4([1,2,3,4],ROOT_INT,ROOT_INT,ROOT_INT)

  # ancestor will be the next higher up.
def question5(ll,m):
  """ FInd the element in a singly linked list that's m elements from the end.
  Args:
    ll: first node of the linked list.
    m: The number of linked list it goes through
  """
  counter = 1
  current = ll
  while current.next is not None:
    counter+=1
    current = current.next
    
  if m ==1:
      return current.data

  # Counter is the total of linked elements there are. Next is to find the
  # number of position where it is mth from the end.
  reverse_m = counter - m + 1
  if reverse_m <= 0:
      raise ValueError("Please input M size that is less than the current size.")
  next_current = ll
  second_counter = 1
  while next_current.next is not None:
    if second_counter == reverse_m:
      return next_current.data
      break
    else:
      next_current = next_current.next      
      second_counter +=1


class Node(object):
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList(object):
    def __init__(self, head=None):
        self.head = head
    
    def tophead(self):
        return self.head

    def append(self, new_element):
        current = self.head
        if self.head:
            while current.next:
                current = current.next
            current.next = new_element
        else:
            self.head = new_element
    
    def display(self):
        current = self.head
        while current.next:
            print current.data
            current = current.next

node = Node("Come Together")
node2 = Node("Yesterday")
node3 = Node("Blackbirds")
node4 = Node("Hey Jude")
node5 = Node("Yellow Submarine")

test = LinkedList(node)
test.append(node2)
test.append(node3)
test.append(node4)
test.append(node5)

test.tophead()

print "This is a question 5 test cases:"
print question5(test.tophead(), 4)
# Output is Yesterday.
print question5(test.tophead(),3)
# Output is Blackbirds.
print question5(test.tophead(),0)
# Output is None.
